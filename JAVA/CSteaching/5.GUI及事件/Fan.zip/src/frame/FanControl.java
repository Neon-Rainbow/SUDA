package frame;

public class FanControl {
    public static void main(String[] args) {
        new FanFrame().init();
    }
}

