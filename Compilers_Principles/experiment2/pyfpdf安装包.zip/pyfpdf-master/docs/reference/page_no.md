## page_no ##

```python
fpdf.page_no()
```

### Description ###

Returns the current page number.

### See also ###

[alias_nb_pages](alias_nb_pages.md).
