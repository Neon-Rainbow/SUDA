## get_y ##

```python
fpdf.get_y()
```
### Description ###

Returns the ordinate of the current position.


### See also ###

[get_x](get_x.md), [set_x](set_x.md), [set_y](set_y.md), [set_xy](set_xy.md).
