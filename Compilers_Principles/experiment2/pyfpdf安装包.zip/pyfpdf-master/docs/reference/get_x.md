## get_x ##

```python
fpdf.get_x()
```
### Description ###

Returns the abscissa of the current position.


### See also ###

[get_y](get_y.md), [set_x](set_x.md), [set_y](set_y.md), [set_xy](set_xy.md).
